To use this example you need to have two things.
* SDK 13 
* The s140_nrf52840_5.0.0-3.alpha.

This zip file contains a diff of the required modifications to the SDK to make
the ble_app_att_mtu_throughput compile with the new header files.

In addition there is a copy of the modified files, so that the zip can just be
extracted over a new installation of the SDK.

The steps to compile the example:
1. Download the SDK 13 from:
   http://www.nordicsemi.com/eng/nordic/Products/nRF52832/nRF5-SDK-zip/59012
2. Extract the SDK to a location of your wish.
3. Extract the content of this zip-file to the <sdk_location>.
4. Extract the header files from the s140_nrf52840_5.0.0-3.alpha_API\include
   folder to <sdk_location>\components\softdevice\s140\headers folder.
5. Navigate to: examples\ble_central_and_peripheral\experimental\ble_app_att_mtu_throughput\pca10056\s140
6. Compile using your favorite compiler.

Note: When extracting this zip-file over the SDK, you will overwrite some
      files. If this is unwanted, please use a new SDK installation to do it.
      It is also possible to see the modifications in the sdk_diff.patch.


Files in this zip file:
components
components\ble
components\ble\common
components\ble\common\ble_advdata.c
components\boards
components\boards\pca10056.h
examples
examples\ble_central_and_peripheral
examples\ble_central_and_peripheral\experimental
examples\ble_central_and_peripheral\experimental\ble_app_att_mtu_throughput
examples\ble_central_and_peripheral\experimental\ble_app_att_mtu_throughput\main.c
examples\ble_central_and_peripheral\experimental\ble_app_att_mtu_throughput\pca10056\s140\arm4\ble_app_att_mtu_throughput_pca10056_s140.uvproj
examples\ble_central_and_peripheral\experimental\ble_app_att_mtu_throughput\pca10056\s140\arm5_no_packs\ble_app_att_mtu_throughput_pca10056_s140.uvprojx
examples\ble_central_and_peripheral\experimental\ble_app_att_mtu_throughput\pca10056\s140\armgcc\ble_app_att_mtu_throughput_gcc_nrf52.ld
examples\ble_central_and_peripheral\experimental\ble_app_att_mtu_throughput\pca10056\s140\iar\ble_app_att_mtu_throughput_iar_nRF5x.icf
readme.md
sdk_diff.patch
